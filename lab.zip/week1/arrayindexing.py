import numpy as np

p=np.array([12,45,89,90])
print(p[1])


p=np.array([[12,45,89,90],[23,56,78,99]])
print(p[1,2])


#NEGITIVE INDEXING
P=np.array([1,2,3])
print(P[-1])


#SHAPE OF AN ARRAY
n=np.array([1,2,5,6])
print(n.shape)

#RESHAPING OF AN ARRAY
m=np.array([1,2,3,4,5,6])
print(m.reshape(2,3))

#looping through an array
arr=np.array([1,2,3,4])
for i in arr:
    print(i)
    
#intializing zeroes and ones
n=np.array([1,3,5,7])
m=np.array(np.zeros((3,4)))
print(m)
import numpy as np

#SHAPE OF AN ARRAY
n=np.array([1,2,5,6])
print(n.shape)

#RESHAPING OF AN ARRAY
m=np.array([1,2,3,4,5,6])
print(m.reshape(2,3))
import numpy as np

#intializing zeroes and ones
n=np.array([1,3,5,7])
m=np.array(np.zeros((3,4)))
print(m)

#slicing
import numpy as np
n=np.array([1,2,3,4,5,6])
print(n[1:5])
