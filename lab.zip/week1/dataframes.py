import pandas as pd 
data={'apples':[3,1,8,0],'oranges':[0,3,6,4]}
df=pd.DataFrame(data)
print(df)

import pandas as pd 
data={'apples':[3,1,8,0],'oranges':[0,3,6,4]}
index=['tom', 'dick','harry','sally']
df=pd.DataFrame(data,index=index)
print(df)