import pandas as pd 
df=pd.read_csv('Iris.csv')
print(df)

print(df.head(10))
print(df.info())
print(df.shape) 
dup_df = pd.concat([df, df], ignore_index=True)
print(dup_df.shape)
#to remove all duplicates
dup_df.drop_duplicates(inplace=True)
print(dup_df.shape)
print(df.describe())
