import matplotlib.pyplot as plt
plt.scatter(pca_df['PC1'], pca_df['PC2'], alpha=0.7)
plt.xlabel('Principle Component 1')
plt.ylabel('principle Component 2')
plt.title('PCA Projection of Tips Dataset')
plt.show()